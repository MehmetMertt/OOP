#include "Part.h"

Part::Part(float durability)
{
    //ctor
    this->durability = durability;
}

Part::~Part()
{
    //dtor
}
